import assert from 'node:assert/strict';

// Reproduit le contrat V31 avec un enrichissement routier qui ne répond jamais.
let baseStarts = 0;
let profileStarts = 0;
const state = { pattern: { stops: [{}, {}] } };
const V16 = { simLoading: false, simCurrentMps: 12, currentRoadLimit: 90 };
const baseStartSimulation = () => { baseStarts += 1; };
const prepareSimulationRoadProfile = () => { profileStarts += 1; return new Promise(() => {}); };

function startSimulation() {
  if (!state.pattern) return;
  V16.simCurrentMps = 0;
  V16.currentRoadLimit = 50;
  baseStartSimulation();
  if (!V16.simLoading) prepareSimulationRoadProfile().catch(() => {});
}

startSimulation();
assert.equal(baseStarts, 1, 'la course doit démarrer sans attendre le profil routier');
assert.equal(profileStarts, 1, 'le profil doit quand même se charger en arrière-plan');
assert.equal(V16.simCurrentMps, 0);
assert.equal(V16.currentRoadLimit, 50);
console.log('OK - simulation lancée immédiatement avec profil routier bloqué');
