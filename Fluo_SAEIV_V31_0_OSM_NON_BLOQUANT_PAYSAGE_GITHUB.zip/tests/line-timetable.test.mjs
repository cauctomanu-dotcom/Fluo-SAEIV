import assert from 'node:assert/strict';
import fs from 'node:fs';

const root = new URL('../', import.meta.url);
const html = fs.readFileSync(new URL('index.html', root), 'utf8');
const routes54 = JSON.parse(fs.readFileSync(new URL('data/54/routes.json', root), 'utf8'));
const route = routes54.routes.find(item => item.short === '54R410');

assert.ok(route, 'la ligne officielle 54R410 doit être disponible');
const payload = JSON.parse(fs.readFileSync(new URL(`data/54/${route.file}`, root), 'utf8'));
const trips = payload.patterns.flatMap(pattern => pattern.trips || []);

assert.equal(payload.patterns.length, 17, 'les 17 parcours officiels 54R410 doivent être chargés');
assert.equal(trips.length, 95, 'les 95 départs officiels 54R410 doivent être disponibles');
assert.ok(payload.patterns.every(pattern => pattern.stops.length > 1), 'chaque parcours doit comporter ses arrêts');
assert.ok(trips.every(trip => Array.isArray(trip.times) && trip.times.length > 1), 'chaque départ doit comporter ses horaires arrêt par arrêt');

const module = html.slice(html.indexOf('<script id="v309LineTimetable">'), html.indexOf('<script id="v309FinalLabel">'));
assert.ok(module.includes("button.id='v309TimetableOpen'"), 'le bouton de fiche horaire doit être créé');
assert.ok(module.includes('id="v309Timetable"'), 'la fenêtre de fiche horaire doit être créée');
assert.ok(module.includes("document.addEventListener('click'"), 'l’ouverture doit utiliser la délégation de clic fiable');
assert.ok(module.includes('serviceActive(trip.service,date)'), 'les départs doivent respecter la date de service GTFS');
assert.ok(module.includes('p.stops.map'), 'le détail doit afficher tous les arrêts du parcours');
assert.ok(!module.includes('fetch('), 'la fiche doit rester hors ligne et ne lancer aucune requête externe');

console.log('OK - fiche horaire par ligne et données 54R410 complètes');
