import assert from 'node:assert/strict';
import fs from 'node:fs';

const html = fs.readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const speed = html.slice(html.indexOf('<script id="v305SpeedLimitsPatch">'), html.indexOf('<script id="v307GpsFluidVisuals">'));
const frame = html.slice(html.indexOf('simulationFrame=function(ts)'), html.indexOf('// --- Calculateur d\'horaires ---'));

assert.ok(speed.includes('maxspeed:bus:forward'), 'les limitations bus directionnelles doivent être demandées');
assert.ok(speed.includes("t['maxspeed:forward']"), 'les limitations directionnelles générales doivent être interprétées');
assert.ok(speed.includes('AbortController'), 'une requête OSM lente doit être interrompue');
assert.ok(speed.includes("CACHE_KEY='fluoMaxspeedProfilesV31'"), 'les profils OSM doivent être mis en cache');
assert.ok(speed.includes("setTimeout(()=>buildProfile(force)"), 'la collecte doit démarrer en différé');
assert.ok(speed.includes('profil local de secours'), 'le profil local doit rester le secours explicite');
assert.ok(frame.includes('window.FluoSpeedLimitsV305?.limitAtAlong'), 'la simulation doit utiliser maxspeed lorsqu’il est disponible');
assert.ok(frame.includes('Math.min(100,osmSpeed)'), 'le car doit rester plafonné à 100 km/h');
assert.ok(frame.includes(':localSpeed'), 'la simulation doit conserver le profil local si OSM manque');

console.log('OK - limitations OSM différées, mises en cache et non bloquantes');
