import assert from 'node:assert/strict';
import fs from 'node:fs';

const html = fs.readFileSync(new URL('../index.html', import.meta.url), 'utf8');
const layout = html.slice(html.indexOf('<script id="v31LandscapeDriverLayout">'), html.indexOf('<script id="v309FinalLabel">'));

assert.ok(layout.includes("bottom.id='v31LandscapeBottom'"), 'la barre de commandes inférieure doit exister');
assert.ok(layout.includes('data-v31-target="speak"'), 'la commande Annoncer doit être disponible en bas');
assert.ok(layout.includes('data-v31-target="v15RequestsBtn"'), 'les demandes clients doivent être disponibles en bas');
assert.ok(layout.includes('grid-row:1/3'), 'la colonne d’informations doit conserver toute la hauteur');
assert.ok(layout.includes('white-space:normal!important'), 'les intitulés doivent pouvoir revenir à la ligne');
assert.ok(layout.includes('state?.route?.long'), 'le nom complet de la ligne doit être affiché');
assert.ok(layout.includes("stops?.at(-1)?.name"), 'la destination physique complète doit être affichée');

console.log('OK - commandes paysage en bas et informations complètes à droite');
